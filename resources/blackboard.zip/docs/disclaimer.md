## Disclaimer

This C4 model is based loosely on an old version of the Blackboard architecture and no longer reflects the current state of the architecture.
