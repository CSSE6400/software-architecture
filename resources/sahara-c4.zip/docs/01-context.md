## System Context

Customers can find and purchase products through Saraha eCommerce's on-line store.
The on-line store uses a data mining service to track customer behaviour and suggest related products.

![](embed:context_diagram)