# Basic Terraform Demo

This will create a VPC in the `ap-southeast` region of AWS. In it will be some networking stuff and a Ubuntu VM.


To run it:

1. Make sure you have the AWS cli installed and logged in
2. `terraform init`
3. `terraform apply`


and don't forget to `terraform destroy` when you're done.